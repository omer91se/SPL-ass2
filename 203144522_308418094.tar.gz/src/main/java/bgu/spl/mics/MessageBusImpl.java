package bgu.spl.mics;
import java.util.ListIterator;
import java.util.Queue;
import java.util.LinkedList;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicReference;

import javafx.util.Pair;


/**
 * The {@link MessageBusImpl class is the implementation of the MessageBus interface.
 * Write your implementation here!
 * Only private fields and methods can be added to this class.
 */
public class MessageBusImpl implements MessageBus {

	private static AtomicReference<MessageBusImpl> bus = null;
	private ConcurrentMap<MicroService,Queue<Message>> queueList;
	private ConcurrentMap<Class,Pair<LinkedList<Queue<Message>>,Queue<Message>>> eventList;
	private ConcurrentMap<Class,LinkedList<Queue<Message>>> broadcastList;
	private ConcurrentMap<Message,Future> eventFutureMap;
	private Object lockEvent;
	private Object lockBroadcast;


	private MessageBusImpl(){
		queueList = new ConcurrentHashMap<>();
		eventList = new ConcurrentHashMap<>();
		broadcastList = new ConcurrentHashMap<>();
		eventFutureMap = new ConcurrentHashMap<>();
	}

	/**
	 * Checks if the singleton instance is constructed, if not call its private constructor.
	 * <p>
	 * @return The instance of the {@link MessageBusImpl}.
	 */
	public static MessageBusImpl getInstance(){

		MessageBusImpl nBus;

		//Checks if bus was already constructed
		if(bus.get() == null) {
			nBus = new MessageBusImpl();
			//Makes sure that only one thread initialized bus.
			bus.compareAndSet(null, nBus);
		}
		return bus.get();
	}

	@Override
	public <T> void subscribeEvent(Class<? extends Event<T>> type, MicroService m) {

		//If there is a MicroService that is already subscribed to type {@param type},
		//find the list of MicroServices queues of type {@param type}.
		//and insert m's queue to that list.
		synchronized (lockEvent) {
			if (eventList.containsKey(type.getClass())) {
				Queue<Message> mQueue = queueList.get(m);
				eventList.get(type.getClass()).getKey().add(mQueue);
			} else {
				LinkedList<Queue<Message>> list = new LinkedList<>();
				list.add(queueList.get(m));

				//Create a new pair of the list above and the queue of m.
				Pair<LinkedList<Queue<Message>>, Queue<Message>> pair = new Pair<>(list, queueList.get(m));

				eventList.put(type.getClass(), pair);
			}
		}
	}

	@Override
	public void subscribeBroadcast(Class<? extends Broadcast> type, MicroService m) {

		//If there is a MicroService that is already subscribed to type {@param type},
		//find the list of MicroServices queues of type {@param type}.
		//and insert m's queue to that list.
		synchronized (lockBroadcast) {
			if (broadcastList.containsKey(type.getClass())) {
				Queue<Message> mQueue = queueList.get(m);
				broadcastList.get(type.getClass()).add(mQueue);
			}
			else {
				LinkedList<Queue<Message>> list = new LinkedList<>();
				list.add(queueList.get(m));

				broadcastList.put(type.getClass(), list);
			}
		}
	}


	@Override
	public <T> void complete(Event<T> e, T result) {

		//resolves e's Future with result.
		eventFutureMap.get(e).resolve(result);
	}

	@Override
	public void sendBroadcast(Broadcast b) {

		//Check if there are MicroServices register to b's type.
		if(broadcastList.containsKey(b.getClass()))
			//Insert b to all the MicroServices that are register to b's type.
			for (Queue<Message> q : broadcastList.get(b.getClass()))
				q.add(b);

			notifyAll();
	}


	@Override
	public <T> Future<T> sendEvent(Event<T> e) {
		synchronized (lockEvent) {
			LinkedList<Queue<Message>> list = eventList.get(e.getClass()).getKey();
			Queue<Message> q = eventList.get(e.getClass()).getValue();


			if (eventList.containsKey(e.getClass())) {
				//add e to the relevant(by round-robin) MicroService's queue.
				q.add(e);

				//Updates the relevant MicrosService's queue.
				Pair<LinkedList<Queue<Message>>, Queue<Message>> pair = new Pair<>(list, robinHood(list, q));
				eventList.remove(e.getClass()).getValue();
				eventList.put(e.getClass(), pair);

				Future<T> f = new Future<>();
				eventFutureMap.put(e, f);
				notifyAll();
				return f;
			}
			return null;
		}
	}

	@Override
	public void register(MicroService m) {

		//Create a new queue for m and insert it to queueList.
		Queue<Message> queue = new LinkedList<>();
		queueList.put(m,queue);
	}

	@Override
	public void unregister(MicroService m) {
		Queue<Message> mQueue = queueList.get(m);

		//Removes m's queue from the broadcastList.
		for(Map.Entry<Class,LinkedList<Queue<Message>>> entry : broadcastList.entrySet()){
			entry.getValue().remove(mQueue);
		}
		//Removes m and m's queue from queueList.
		queueList.remove(m);

		synchronized(lockEvent) {

			//Iterates over eventList and removes mQueue from the relevant lists.
			for (Map.Entry<Class, Pair<LinkedList<Queue<Message>>, Queue<Message>>> entry : eventList.entrySet()) {

				//A lock is needed here because the queue that indicates the next iteration in round robin
				//is a shared object between different threads.


				//Checks if mQueue is the next relevant queue in round robin.
				if (entry.getValue().getValue() == mQueue) {

					//Creates a new pair with the next queue in round robin method.
					Pair<LinkedList<Queue<Message>>, Queue<Message>> p = new Pair<>(entry.getValue().getKey(), robinHood(entry.getValue().getKey(), mQueue));

					//Updates the eventList with the new pair
					entry.setValue(p);
				}


				//Removes m's queue from event queue list if it is there.
				entry.getValue().getKey().remove(mQueue);
			}
		}

	}

	@Override
	public Message awaitMessage(MicroService m) throws InterruptedException {

		//If m's message queue is empty, wait, until notified.
		while(queueList.get(m).isEmpty()){
			wait();
		}
		return queueList.get(m).remove();
	}


	/**
	 * Find the next MicroService's queue by Round-Robin manner.
	 * <p>
	 * @param list of events registered to a certain event type.
	 * @param q the last queue that got an event.
	 * @return the queue of the next microService in Round-Robin manner.
	 */
	private Queue<Message> robinHood(LinkedList<Queue<Message>> list ,Queue<Message> q) {
		synchronized (lockEvent) {

			//Create an iterator that points to q.
			ListIterator<Queue<Message>> qIterator = list.listIterator(list.indexOf(q));
			if (qIterator.hasNext())
				return qIterator.next();
			else
				return list.getFirst();
		}
	}


}
